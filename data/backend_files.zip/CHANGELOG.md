# Changelog

All notable changes to this project are documented in this file.

## [0.2.0] - 2026-03-10

### Added

- Backend v1 FastAPI service under `app/`
- CSV demo datasets under `data/`
- Graph-based financial digital twin construction
- Four rule-based risk detections and investigation report generation
- Release notes file `releases/v0.2.0.md`

### Changed

- Reworked README to document backend architecture, setup, and API workflow
- Expanded contribution guide with backend validation checklist
- Updated `.gitignore` for Python development artifacts and secrets

### Security

- Replaced real-looking API key in `.env.example` with a safe placeholder

## [0.1.0] - 2026-03-09

### Added

- Initial repository structure
- Collaboration and contribution guidelines
- Release note template and first version note

