# Contributing Guide

## Branch Naming

- Features: `feature/<name>-<task>`
- Fixes: `fix/<name>-<task>`
- Docs: `docs/<name>-<task>`

## Commit Style

Use clear, scoped commit messages:

- `feat: add graph-based risk detection endpoint`
- `fix: validate missing invoice columns`
- `docs: update backend setup guide`

## Local Development

1. Create and activate a virtual environment.
2. Install dependencies with `pip install -r requirements.txt`.
3. Copy `.env.example` to `.env`.
4. Run `uvicorn app.main:app --reload`.
5. Use `http://localhost:8000/docs` for endpoint checks.

## Pull Request Rules

1. Open PR against `main`.
2. Keep each PR focused on one concern.
3. Include logs, sample responses, or screenshots when behavior changes.
4. Require at least 1 approval before merge.
5. Resolve all review comments before merge.

## Backend Change Checklist

Before opening a PR for backend changes:

1. Run the API flow in order: `/upload-data`, `/build-graph`, `/detect-risk`, `/investigation`.
2. Confirm the app starts with no import/runtime errors.
3. Ensure no secrets are committed (`.env` must stay untracked).
4. Update docs if endpoint behavior, policies, or setup steps changed.

## Versioning Rules

For every release:

1. Update `CHANGELOG.md`.
2. Add release notes in `releases/vX.Y.Z.md`.
3. Create and push git tag `vX.Y.Z` after merge.

