# Project Changes Log

## Phase 1 — Dataset Expansion

**Files:** `data/vendors.csv`, `data/invoices.csv`, `data/approvals.csv`, `data/transactions.csv`

- Vendors: 3 → 10 (added ghost vendor `Phantom Services` with no approval records)
- Invoices: 5 → 14 (added duplicates, split invoices, amount-mismatched entries)
- Approvals: 5 → 13 (added SoD violations, missing approvals, non-senior approvers)
- Transactions: 5 → 14 (added rapid payments, large payments, dormant vendor reactivations)

---

## Phase 2 — Graph Rewrite

**File:** `app/graph.py`

- Rewrote from scratch to use **NetworkX DiGraph** properly
- Added 5 node types: `vendor`, `invoice`, `approval_decision`, `transaction`, `employee`
- `ApprovalDecision` nodes are first-class graph nodes (not just edge attributes)
- Edges: vendor→invoice, invoice→approval_decision, approval_decision→transaction, employee→approval_decision, employee→transaction
- Graph stats: **68 nodes, 64 edges**
- `i6` (Phantom Services) deliberately has no `approval_decision` node — used by `missing_approval` rule

---

## Phase 3 — Risk Detection Rewrite

**File:** `app/risk.py`

- Completely rewrote to use **graph traversal** (NetworkX) instead of Pandas DataFrames
- Added `inr(amount)` helper — formats amounts as `₹X,XX,XXX`
- 8 detection rules implemented:

| Rule | Description |
|------|-------------|
| `segregation_of_duties` | Same employee both raised invoice and approved it |
| `invoice_splitting` | Multiple invoices to same vendor within 3 days, combined total > ₹12.6M threshold |
| `rapid_vendor_to_payment` | Vendor onboarded < 7 days before first payment |
| `large_payment_no_senior_approver` | Payment > ₹42M without `user_88` or `user_99` as approver |
| `missing_approval` | Invoice has a transaction but no approval_decision node |
| `duplicate_invoice` | Same vendor + same amount within 3 days |
| `amount_mismatch` | Transaction amount differs from invoice amount |
| `dormant_vendor_reactivation` | Vendor had no activity for 180+ days before this transaction |

- Fires **10 findings** total on the current dataset (`rapid_vendor_to_payment` fires 3 times)

---

## Phase 4 — INR Currency Conversion

**Files:** `app/risk.py`, `app/policy.py`

- All amounts converted to INR (×84 from USD)
- Policy thresholds updated:
  - `invoice_approval_threshold` = ₹12,600,000
  - `large_payment_threshold` = ₹42,000,000
- `inr()` helper added for consistent `₹` formatting throughout findings

---

## Phase 5 — Supporting Module Updates

**`app/state.py`**
- Added `cleaning_report` field
- Added `audit_session` field

**`app/policy.py`**
- Updated thresholds to INR
- Added `senior_approvers = frozenset({"user_88", "user_99"})`

**`app/models.py`**
- Updated Pydantic models to reflect new fields

**`app/investigator.py`**
- Added `audit_session` to investigation report output
- Compressed LLM prompt — only sends `risk_type`, `vendor`, `effect`, `policy_violation` per finding (~400 tokens vs ~2,700 originally)
- `max_tokens` reduced from 400 → 250

**`app/main.py`**
- Added `/data-quality-report` endpoint
- Added `/test-transactions` endpoint
- Added `/run-audit` endpoint (multi-agent pipeline)

---

## Phase 6 — Bug Fixes

| Bug | Fix |
|-----|-----|
| Invoice splitting false positive | Added combined-total check — only flags if sum of split invoices exceeds the threshold, not each individually |
| Stale state on re-upload | Reset `graph`, `risk_findings`, `audit_session`, `investigation_report`, `cleaning_report` before loading new data |
| Missing ₹ symbol in output | `inr()` helper applied to all monetary values in findings |
| `audit_session` lost in report | Explicitly passed through to `generate_report()` return value |

---

## Phase 7 — Data Cleaning Pipeline

**File:** `app/loader.py`

Rewrote with a **6-step cleaning pipeline**:

1. Strip leading/trailing whitespace from all string columns
2. Normalize all ID columns to lowercase
3. Drop rows with null values in required fields
4. Drop fully duplicate rows
5. Drop duplicate primary keys (keep first)
6. Validate that amount columns are numeric and non-negative

Cleaning results stored in `state.cleaning_report` — accessible via `GET /data-quality-report`.

---

## Phase 8 — Transaction Testing

**File:** `app/transaction_tester.py`

5 automated controls run against every transaction:

| Control | Check |
|---------|-------|
| CTRL-1 | Transaction node exists in graph |
| CTRL-2 | Linked invoice exists |
| CTRL-3 | Approval exists (no missing approval) |
| CTRL-4 | No SoD violation (raiser ≠ approver) |
| CTRL-5 | Amount matches invoice (zero tolerance) |

Results on current dataset: **8 PASS / 6 FAIL** (57.1% pass rate)

Known failures: `t1` (SoD), `t4` (large payment, non-senior), `t6` (missing approval), `t10` (amount mismatch) — all intentional fraud scenarios.

---

## Phase 9 — Multi-Agent System (LangGraph)

**Files:** `app/agents/__init__.py`, `app/agents/tools.py`, `app/agents/supervisor.py`

**`app/agents/tools.py`** — 5 LangChain `@tool` wrappers:
- `load_and_clean_data` — runs loader pipeline
- `build_financial_graph` — builds NetworkX graph
- `detect_fraud_risks` — runs all 8 detection rules
- `test_all_transactions` — runs all 5 controls
- `generate_audit_report` — calls LLM for narrative

**`app/agents/supervisor.py`** — LangGraph `StateGraph`:
- `AuditState` TypedDict for shared state
- `supervisor_node` — LLM decides which agent runs next
- `data_agent` — ReAct agent with tools 1-4
- `investigation_agent` — ReAct agent with tool 5
- Flow: `START → supervisor → data_agent → supervisor → investigation_agent → supervisor → END`

**`app/main.py`** — Added `POST /run-audit` endpoint that triggers the full agent pipeline.

**`requirements.txt`** additions:
```
langgraph>=1.1.0
langchain-core>=0.3.0
langchain-groq>=1.1.0
```

---

## Things to Keep in Mind

### Startup
1. Activate the virtual environment: `.\venv\Scripts\Activate.ps1`
2. Ensure `.env` file has `GROQ_API_KEY=your_key`
3. Start the server: `uvicorn app.main:app --reload`

### Correct Endpoint Order
State is in-memory — steps **must** run in sequence:

1. `POST /upload-data` — loads and cleans CSVs
2. `POST /build-graph` — builds the NetworkX graph
3. `POST /detect-risk` — runs 8 detection rules
4. `GET /investigation` — LLM narrative (requires step 3)

Optional (can run after their prerequisites):
- `GET /data-quality-report` — after step 1
- `POST /test-transactions` — after step 2
- `POST /run-audit` — runs everything via agents (~60-90 seconds)

### Groq Free Tier Limits
- 6,000 tokens/minute
- `/investigation` uses ~650 tokens (after compression fix)
- `/run-audit` makes ~6-8 LLM calls — wait for it, do not re-submit
- If you get a **429 error**, wait 60 seconds and retry

### State is In-Memory Only
- Restarting the server wipes all state — re-run steps 1→3
- Re-uploading data automatically resets graph, findings, and reports
- Steps 1-3 take ~2 seconds (no LLM involved)

### Common Errors
| Error | Cause | Fix |
|-------|-------|-----|
| `"No data loaded"` | Called `/build-graph` before `/upload-data` | Run steps in order |
| `"No graph"` | Called `/detect-risk` before `/build-graph` | Run step 2 first |
| `"No findings"` | Called `/investigation` before `/detect-risk` | Run step 3 first |
| HTTP 429 | Groq rate limit hit | Wait 60s and retry |
| `/run-audit` timeout | Normal — 60-90s expected | Just wait |
