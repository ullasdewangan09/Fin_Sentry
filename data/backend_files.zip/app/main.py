from dotenv import load_dotenv

load_dotenv()  # Must run before any module that reads env vars

import io
import os
from datetime import datetime, timezone

import matplotlib
matplotlib.use("Agg")  # Non-interactive backend — must be set before pyplot import
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import networkx as nx

from fastapi import FastAPI, HTTPException
from fastapi.responses import Response

from app.graph import build_graph
from app.investigator import generate_report
from app.loader import load_all_datasets
from app.risk import run_all_detections
from app.state import state
from app.transaction_tester import run_transaction_tests
from app.agents.supervisor import run_audit_pipeline

app = FastAPI(
    title="Decision & Financial Digital Twin Platform",
    description="Hackathon backend prototype — Deloitte Hackplosion 2026",
    version="0.1.0",
)


@app.on_event("startup")
async def auto_run_pipeline():
    """
    Proactive governance: automatically load data, build the digital twin graph,
    and run fraud detection the moment the server starts — no manual trigger needed.
    """
    try:
        load_all_datasets()
        build_graph()
        findings = run_all_detections()
        state.audit_session = {
            "run_at": datetime.now(timezone.utc).isoformat(),
            "records_analyzed": {
                "vendors": len(state.vendors),
                "invoices": len(state.invoices),
                "approvals": len(state.approvals),
                "transactions": len(state.transactions),
            },
            "findings_count": len(findings),
        }
        print(
            f"[AUTO-AUDIT] Startup pipeline complete — "
            f"{len(findings)} risk finding(s) detected across "
            f"{state.graph.number_of_nodes()} nodes / {state.graph.number_of_edges()} edges."
        )
    except Exception as exc:
        print(f"[AUTO-AUDIT] Startup pipeline failed — {exc}")


@app.post("/upload-data")
def upload_data():
    """Load all CSV datasets from the data/ directory into in-memory state."""
    # Reset all derived state before loading so stale data never persists
    state.graph = None
    state.risk_findings = []
    state.audit_session = None
    state.investigation_report = None
    state.cleaning_report = None

    try:
        results = load_all_datasets()
        return {
            "message": "Datasets loaded successfully",
            "datasets_loaded": len(results),
            "summary": {name: len(df) for name, df in results.items()},
        }
    except (FileNotFoundError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/build-graph")
def build_digital_twin():
    """Construct the typed financial digital twin graph from loaded datasets."""
    if state.vendors is None:
        raise HTTPException(
            status_code=400,
            detail="Data not loaded. Call POST /upload-data first.",
        )

    G = build_graph()

    node_types = {
        nt: sum(1 for _, d in G.nodes(data=True) if d.get("node_type") == nt)
        for nt in ["employee", "vendor", "vendor_creation", "invoice", "approval_decision", "transaction"]
    }

    return {
        "message": "Financial digital twin built successfully",
        "nodes": G.number_of_nodes(),
        "edges": G.number_of_edges(),
        "node_types": node_types,
    }


@app.post("/detect-risk")
def detect_risk():
    """Run all rule-based risk detection against the digital twin graph."""
    if state.graph is None:
        raise HTTPException(
            status_code=400,
            detail="Graph not built. Call POST /build-graph first.",
        )

    findings = run_all_detections()

    audit_session = {
        "run_at": datetime.now(timezone.utc).isoformat(),
        "records_analyzed": {
            "vendors": len(state.vendors),
            "invoices": len(state.invoices),
            "approvals": len(state.approvals),
            "transactions": len(state.transactions),
        },
        "findings_count": len(findings),
    }
    state.audit_session = audit_session

    return {
        "message": f"{len(findings)} risk pathway(s) detected",
        "total_risks": len(findings),
        "risk_types": [f["risk_type"] for f in findings],
        "audit_session": audit_session,
    }


@app.get("/investigation")
def get_investigation():
    """Return the full structured investigation report with AI-generated narrative."""
    if not state.risk_findings:
        raise HTTPException(
            status_code=400,
            detail="No risk findings available. Call POST /detect-risk first.",
        )

    return generate_report()


@app.get("/data-quality-report")
def data_quality_report():
    """Return the cleaning report produced when data was last uploaded."""
    if state.cleaning_report is None:
        raise HTTPException(
            status_code=400,
            detail="No data loaded yet. Call POST /upload-data first.",
        )

    total_issues = sum(len(log["issues"]) for log in state.cleaning_report)
    return {
        "message": "Data quality report",
        "datasets_checked": len(state.cleaning_report),
        "total_issues_found": total_issues,
        "overall_clean": total_issues == 0,
        "details": state.cleaning_report,
    }


@app.post("/test-transactions")
def test_transactions():
    """Run 5 internal controls against every loaded transaction and return pass/fail results."""
    if state.graph is None:
        raise HTTPException(
            status_code=400,
            detail="Graph not built. Call POST /build-graph first.",
        )

    try:
        report = run_transaction_tests()
    except RuntimeError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    return report


@app.post("/run-audit")
def run_audit(prompt: str = "Run the full financial audit pipeline."):
    """
    Trigger the autonomous two-agent audit pipeline end-to-end.

    Agent 1 — Data & Detection (Steps 1-3):
      loads & cleans data → builds financial digital twin graph → detects fraud risks

    Agent 2 — Investigation & Reporting (Steps 4-6):
      tests all transactions → generates LLM executive audit narrative

    A LangGraph supervisor orchestrates routing between the two agents.
    This single endpoint replaces the manual 5-step call sequence.
    """
    try:
        result = run_audit_pipeline(prompt)
    except RuntimeError as exc:
        raise HTTPException(status_code=500, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Pipeline error: {exc}")

    return result


@app.get("/policy")
def get_policy():
    """
    Return the active policy configuration.
    Policy is ingested from data/policy.json at server startup.
    Edit that file and restart to change thresholds without code changes.
    """
    from app.policy import POLICY, _POLICY_PATH
    return {
        "source": _POLICY_PATH if os.path.exists(_POLICY_PATH) else "built-in defaults",
        "invoice_approval_threshold": POLICY.invoice_approval_threshold,
        "large_payment_threshold": POLICY.large_payment_threshold,
        "senior_approvers": sorted(POLICY.senior_approvers),
        "invoice_splitting_window_days": POLICY.invoice_splitting_window_days,
        "invoice_splitting_min_count": POLICY.invoice_splitting_min_count,
        "rapid_payment_max_days": POLICY.rapid_payment_max_days,
        "dormancy_threshold_days": POLICY.dormancy_threshold_days,
        "amount_mismatch_tolerance": POLICY.amount_mismatch_tolerance,
    }


@app.get("/graph/image")
def graph_image():
    """
    Return a PNG visualization of the financial digital twin graph.
    Nodes are colour-coded by type: employee, vendor, vendor_creation,
    invoice, approval_decision, transaction.
    """
    if state.graph is None:
        raise HTTPException(
            status_code=400,
            detail="Graph not built. Call POST /build-graph first.",
        )

    G = state.graph

    color_map = {
        "vendor": "#4A90D9",
        "employee": "#27AE60",
        "vendor_creation": "#1ABC9C",
        "invoice": "#F39C12",
        "approval_decision": "#E74C3C",
        "transaction": "#9B59B6",
    }
    node_colors = [
        color_map.get(G.nodes[n].get("node_type"), "#95A5A6")
        for n in G.nodes()
    ]

    fig, ax = plt.subplots(figsize=(22, 16))
    pos = nx.spring_layout(G, seed=42, k=1.8)
    nx.draw(
        G, pos, ax=ax,
        node_color=node_colors,
        node_size=280,
        with_labels=False,
        arrows=True,
        arrowsize=8,
        edge_color="#BBBBBB",
        width=0.6,
    )

    legend_elements = [
        mpatches.Patch(facecolor="#27AE60", label="Employee"),
        mpatches.Patch(facecolor="#4A90D9", label="Vendor"),
        mpatches.Patch(facecolor="#1ABC9C", label="Vendor Creation (Decision Node)"),
        mpatches.Patch(facecolor="#F39C12", label="Invoice"),
        mpatches.Patch(facecolor="#E74C3C", label="Approval Decision"),
        mpatches.Patch(facecolor="#9B59B6", label="Transaction"),
    ]
    ax.legend(handles=legend_elements, loc="upper left", fontsize=11, framealpha=0.9)
    ax.set_title(
        "Decision & Financial Digital Twin — Control Pathway Graph\n"
        f"{G.number_of_nodes()} nodes  |  {G.number_of_edges()} edges",
        fontsize=14,
        fontweight="bold",
        pad=16,
    )

    buf = io.BytesIO()
    plt.savefig(buf, format="png", dpi=150, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    buf.seek(0)

    return Response(content=buf.read(), media_type="image/png")
