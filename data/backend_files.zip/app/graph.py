import networkx as nx

from app.state import state


def build_graph() -> nx.DiGraph:
    G = nx.DiGraph()

    vendors = state.vendors
    invoices = state.invoices
    approvals = state.approvals
    transactions = state.transactions

    # Employee → performed → VendorCreation → onboarded → Vendor
    # VendorCreation is a first-class decision node representing the act of
    # registering a vendor in the system — a detectable decision pathway.
    for _, row in vendors.iterrows():
        vc_id = f"vc_{row['vendor_id']}"
        G.add_node(
            row["vendor_id"],
            node_type="vendor",
            name=row["name"],
            created_date=str(row["created_date"].date()),
            created_by=row["created_by"],
        )
        G.add_node(
            vc_id,
            node_type="vendor_creation",
            created_by=row["created_by"],
            created_date=str(row["created_date"].date()),
            vendor_id=row["vendor_id"],
        )
        G.add_node(row["created_by"], node_type="employee")
        G.add_edge(
            row["created_by"],
            vc_id,
            edge_type="performed",
            date=str(row["created_date"].date()),
        )
        G.add_edge(
            vc_id,
            row["vendor_id"],
            edge_type="onboarded",
            date=str(row["created_date"].date()),
        )

    # Vendor → issued → Invoice
    for _, row in invoices.iterrows():
        G.add_node(
            row["invoice_id"],
            node_type="invoice",
            amount=row["amount"],
            date=str(row["date"].date()),
            created_by=row["created_by"],
        )
        G.add_edge(
            row["vendor_id"],
            row["invoice_id"],
            edge_type="issued",
            date=str(row["date"].date()),
        )

    # Invoice → has_approval → ApprovalDecision → approved_by → Employee
    # Invoices with no approval row are intentionally absent — their missing
    # ApprovalDecision node is itself a detectable signal (ghost vendor / bypass).
    for _, row in approvals.iterrows():
        ad_id = f"AD-{row['invoice_id']}"
        G.add_node(
            ad_id,
            node_type="approval_decision",
            approved_by=row["approved_by"],
            invoice_id=row["invoice_id"],
        )
        G.add_node(row["approved_by"], node_type="employee")
        G.add_edge(row["invoice_id"], ad_id, edge_type="has_approval")
        G.add_edge(ad_id, row["approved_by"], edge_type="approved_by")

    # Invoice → paid_by → Transaction
    for _, row in transactions.iterrows():
        G.add_node(
            row["transaction_id"],
            node_type="transaction",
            amount=row["amount"],
            date=str(row["date"].date()),
        )
        G.add_edge(
            row["invoice_id"],
            row["transaction_id"],
            edge_type="paid_by",
            date=str(row["date"].date()),
        )

    state.graph = G
    return G
