import json
import os
from dataclasses import dataclass

_POLICY_PATH = "data/policy.json"


@dataclass(frozen=True)
class PolicyConfig:
    # Invoices at or above this amount require managerial approval
    invoice_approval_threshold: float = 12_600_000.0  # ₹1.26 Cr (was $150,000)

    # Invoices above this amount require a designated senior approver
    large_payment_threshold: float = 42_000_000.0  # ₹4.2 Cr (was $500,000)

    # User IDs designated as senior approvers
    senior_approvers: frozenset = frozenset({"user_88", "user_99"})

    # Maximum days between invoices to classify as a splitting cluster
    invoice_splitting_window_days: int = 3

    # Minimum number of sub-threshold invoices to flag as splitting
    invoice_splitting_min_count: int = 2

    # Maximum days from vendor creation to first payment to flag as rapid cycle
    rapid_payment_max_days: int = 7

    # Minimum days of inactivity before a vendor is considered dormant
    dormancy_threshold_days: int = 180

    # Tolerance for invoice vs transaction amount comparison (0 = exact match required)
    amount_mismatch_tolerance: float = 0.0


def _load() -> PolicyConfig:
    """Load policy settings from data/policy.json if present, else use defaults."""
    if os.path.exists(_POLICY_PATH):
        with open(_POLICY_PATH) as fh:
            data = json.load(fh)
        if "senior_approvers" in data:
            data["senior_approvers"] = frozenset(data["senior_approvers"])
        return PolicyConfig(**data)
    return PolicyConfig()


POLICY = _load()
