# Deloitte Hack

Financial Digital Twin backend prototype built for Deloitte Hackplosion 2026.

## Repository Scope

This repository now includes:

- Backend v1 API for data ingestion, graph construction, and risk detection
- Demo ERP-like datasets for local testing
- Team collaboration and release documentation

## Backend v1 Overview

The backend models financial activity as a typed relationship graph and flags
control-bypass pathways through rule-based checks.

### Core capabilities

- Load and validate `vendors`, `invoices`, `approvals`, and `transactions` CSVs
- Build an in-memory `networkx.DiGraph` financial digital twin
- Detect 4 governance risk patterns
- Generate a structured investigation report
- Optionally generate an executive narrative using Groq (`GROQ_API_KEY`)

## Project Structure

```text
app/
  main.py           # FastAPI endpoints
  loader.py         # CSV loading + schema validation
  graph.py          # Digital twin graph construction
  risk.py           # Rule-based risk detections
  policy.py         # Threshold and policy configuration
  investigator.py   # Report assembly + Groq narrative call
  state.py          # Shared in-memory app state
  models.py         # Response model definitions
data/
  vendors.csv
  invoices.csv
  approvals.csv
  transactions.csv
releases/
  VERSION_TEMPLATE.md
  v0.1.0.md
  v0.2.0.md
```

## API Workflow

Call endpoints in this order:

1. `POST /upload-data` - Load and validate CSV datasets
2. `POST /build-graph` - Build the typed digital twin graph
3. `POST /detect-risk` - Run all rule-based detections
4. `GET /investigation` - Return findings + optional LLM narrative

### Expected demo output with included dataset

- Graph size: `18` nodes, `18` edges
- Total risk findings: `4`
- Risk types:
  - `segregation_of_duties`
  - `invoice_splitting`
  - `rapid_vendor_to_payment`
  - `policy_violation_large_payment`

## Risk Rules (Configured in `app/policy.py`)

- Segregation of Duties: vendor creator cannot approve that vendor's invoices
- Invoice Splitting: at least 2 invoices below `150000` within a 3-day window
- Rapid Vendor-to-Payment: first payment within 7 days of vendor creation
- Large Payment Approval: invoices above `500000` must be approved by a
  designated senior approver

## Local Setup

### Prerequisites

- Python 3.10+
- Pip
- Groq API key (optional but recommended for narrative generation)

### Run locally (PowerShell)

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

Open Swagger at `http://localhost:8000/docs`.

If `GROQ_API_KEY` is not set, the investigation endpoint still returns
structured findings and degrades the narrative field gracefully.

## Team

- Repo owner: `Zian-Surani`
- Collaborator 1: `DiStrix1`
- Collaborator 2: `000Shreeharish000`
- Collaborator 3: `4Anj`
- Collaborator 4: `shivanshihi`

## Collaboration and Releases

- Contribution guide: [CONTRIBUTING.md](CONTRIBUTING.md)
- Version history: [CHANGELOG.md](CHANGELOG.md)
- Release note template: [releases/VERSION_TEMPLATE.md](releases/VERSION_TEMPLATE.md)

